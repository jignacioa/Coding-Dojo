from django.apps import AppConfig


class SemiRestfulTvshowsAppConfig(AppConfig):
    name = 'semi_restful_tvshows_app'
