from django.shortcuts import render, HttpResponse

def index(request):
    return HttpResponse('it works')

# Create your views here.
