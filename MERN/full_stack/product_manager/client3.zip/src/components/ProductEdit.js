import React, {useState, useEffect} from 'react'
import {navigate} from '@reach/router'
import axios from 'axios'



export default function ProductEdit({id}) {
    const [productName, setName] = useState('')
    const [productPrice, setPrice] = useState(0)
    const [description, setDesc] = useState('')
   
    useEffect(() => {
        axios.get('http://localhost:8000/api/products/' + id)
         .then(response => {
             setName(response.data.productName)
             setPrice(response.data.productPrice)
             setDesc(response.data.description)
         })
         .catch(err => console.log(err))
         
    }, [id])
    
    const handleSubmit = e => {
        e.preventDefault()
        axios.put('http://localhost:8000/api/products/' + id, {
            productName,
            productPrice,
            description
        })
          .then(navigate(`/${id}`))
          .catch(err => console.log(err))
    }
    
    return (
        <div>
        <h1>Edit Product</h1>
        <form onSubmit = {handleSubmit}>
            <div>
                <label>Product Name</label>
                <input 
                value ={productName}
                onChange ={e => setName(e.target.value)}/>
            </div>
            <div>
                <label>Price</label>
                <input
                value ={productPrice}
                onChange ={e => setPrice(e.target.value)} />
            </div>
            <div>
                <label>Description</label>
                <input
                value ={description}
                onChange ={e => setDesc(e.target.value)}/>
            </div>
            <button type="text">Submit</button>
        </form>
        <button onClick ={ e => navigate('/')}>Cancel</button>
    </div>
        )
    


    }
 
        
   
    