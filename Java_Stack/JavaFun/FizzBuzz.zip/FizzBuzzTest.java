public class FizzBuzzTest {
    public static void main(String[] args) {
        FizzBuzz test = new FizzBuzz();
        String string1 = test.fizzBuzz(7);
        String string2 = test.fizzBuzz(25);
        String string3 = test.fizzBuzz(9);
        String string4 = test.fizzBuzz(15);
        System.out.println(string1);
        System.out.println(string2);
        System.out.println(string3);
        System.out.println(string4);

    }
}