import React, {useEffect, useState} from 'react'
import axios from 'axios'
import {Link} from '@reach/router'



export default function ProductList() {
    const [products, setProducts] = useState(null)

    useEffect(() => {
        axios.get('http://localhost:8000/api/products')
            .then(res => setProducts(res.data))
            .catch(err => console.log(err))
        
    }, [])
    if (products === null) return 'Loading...'
    console.log(products)
  return (
      <div>
          <table>
              <thead>
                <tr>
                    <td>All Products</td>
                </tr>
              </thead>
              <tbody>
                  {products.map(product => {
                      return(
                  <tr key={product._id}>
                     <td><Link to ={`/${product._id}`}>{product.productName}</Link></td>
                  </tr>
                  )
                })}
              </tbody>
          </table>
      </div>
  )
}