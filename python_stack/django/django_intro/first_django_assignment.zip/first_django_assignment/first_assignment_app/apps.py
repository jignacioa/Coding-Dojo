from django.apps import AppConfig


class FirstAssignmentAppConfig(AppConfig):
    name = 'first_assignment_app'
