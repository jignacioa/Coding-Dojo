import React from 'react';
//import logo from './logo.svg';
import './App.css';
import PokemonApi from './components/PokemonApi'

function App() {
  return (
    <div className="App">
    <PokemonApi/>
    </div>
  );
}

export default App;
