package com.codingdojo.javaexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaexamApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaexamApplication.class, args);
	}

}
