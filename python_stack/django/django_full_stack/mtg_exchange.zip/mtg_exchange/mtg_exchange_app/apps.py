from django.apps import AppConfig


class MtgExchangeAppConfig(AppConfig):
    name = 'mtg_exchange_app'
