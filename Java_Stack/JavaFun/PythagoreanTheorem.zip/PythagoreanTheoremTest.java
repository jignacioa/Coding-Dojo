public class PythagoreanTheoremTest {
    public static void main(String[] args) {
        PythagoreanTheorem first = new PythagoreanTheorem();
        double hypotenuse = first.calculateHypotenuse(5,5);
        System.out.println(hypotenuse);
    }
}