import React from 'react';
//import logo from './logo.svg';
import './App.css';
import HookForm from './components/HookForm'

function App() {
  return (
    <div className="App">
      <HookForm/>
    </div>
  );
}

export default App;
