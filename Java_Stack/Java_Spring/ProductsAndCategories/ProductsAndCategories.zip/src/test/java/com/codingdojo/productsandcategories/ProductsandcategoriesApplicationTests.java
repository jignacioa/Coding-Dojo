package com.codingdojo.productsandcategories;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductsandcategoriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
