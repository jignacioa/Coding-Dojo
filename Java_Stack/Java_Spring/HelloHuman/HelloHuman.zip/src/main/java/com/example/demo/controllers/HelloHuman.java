package com.example.demo.controllers;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
public class HelloHuman {
	@RequestMapping("/")
	public String greetHuman(@RequestParam(value="name", required= false) String firstName, @RequestParam(value="lastname", required= false) String lastName) {
		if((firstName == null) && (lastName == null)){
			return "Hello Human! Welcome to SpringBoot";
		} else {
		return "Hello " + firstName + " " + lastName + "! Welcome to SpringBoot";
		}
	}

}
