from django.urls import path
from . import views

urlpatterns = [
    path('', views.memberlogin),
    path('register', views.registration),
    path('process_registration', views.process_registration),
    path('login', views.process_login),
    path('dashboard', views.dashboard),
    path('dashboard/newproduct', views.newproduct),
    path('dashboard/newproduct/process_submission', views.process_submission),
    path('dashboard/listings', views.listings),
    path('dashboard/listings/<int:product_id>', views.view_product),
    path('listings/<int:product_id>/process_comment', views.process_comment)

]
