import React from 'react';
import Obi from '../Obi.jpeg'

const Error = () => {
 
            return ( 
             <>   
            <h1>These aren't the droids you're looking for</h1> 
            <img src ={Obi} alt="Obi"/>
            </>
            
            )
}

export default Error