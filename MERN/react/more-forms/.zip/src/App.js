import React from 'react';
//import logo from './logo.svg';
import './App.css';
import MoreForms from './components/MoreForms'

function App() {
  return (
    <div className="App">
      <MoreForms/>
    </div>
  );
}

export default App;
