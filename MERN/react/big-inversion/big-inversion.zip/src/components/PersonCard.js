import React from 'react';

const PersonCard = props => {

    return (
        <>
        <h1>{props.firstName}, {props.lastName}</h1>
        <p>Age: {props.age}</p>
        <p>hair Color: {props.hairColor}</p>
        </>
    )


}

export default PersonCard