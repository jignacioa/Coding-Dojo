package com.zookeepertwo;

public class BatTest {

	public static void main(String[] args) {
		Bat newBat = new Bat();
		newBat.attackTown();
		newBat.attackTown();
		newBat.attackTown();
		newBat.eatHumans();
		newBat.eatHumans();
		newBat.fly();
		newBat.fly();
		newBat.displayEnergy();

	}

}
