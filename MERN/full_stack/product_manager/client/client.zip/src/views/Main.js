import React, {useState, useEffect} from 'react'
//import axios from 'axios'
import Form from '../components/productForm'
import ProductList from '../components/productList'
import ProductDetail from '../components/productDetail'
import {Router} from '@reach/router'

export default () => {
    return (
        <div>
            <Form/>
            <ProductList/> 
        </div>
    )
}