import React from 'react';
import Main from './components/Main'
//import Chat from './components/Chat'
//import {Router} from '@reach/router'
import './App.css';


function App() {
  return (
    <div className="App">
      <Main/>
    </div>
  )
}
export default App;