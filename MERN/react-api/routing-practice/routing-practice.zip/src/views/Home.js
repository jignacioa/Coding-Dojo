import React from 'react';


function Home() {
    return (
     <h1>WELCOME</h1>
    )
        
    
}

export default Home