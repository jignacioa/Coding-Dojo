package com.codingdojo.javaexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaexamApplicationTests {

	@Test
	void contextLoads() {
	}

}
