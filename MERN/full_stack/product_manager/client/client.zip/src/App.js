import React from 'react';
//import logo from './logo.svg';
import './App.css';
import Main from './views/Main'
import ProductDetail from './components/productDetail'
import {Router} from '@reach/router'

function App() {
  return (
    <div className="App">
      <Router>
      <Main path ='/'/>
      <ProductDetail path ='/:id'/>
      </Router>
    </div>
  );
}

export default App;
