from django.apps import AppConfig


class SqlToOrmAppConfig(AppConfig):
    name = 'sql_to_orm_app'
