package com.objectmasterone;

public class HumanTest {

	public static void main(String[] args) {
		Human attacker = new Human();
		Human attacked = new Human();
		attacker.attack(attacked);

	}

}
