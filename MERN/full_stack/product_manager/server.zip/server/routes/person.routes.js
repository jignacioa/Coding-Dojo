const ProductCtl = require('../controllers/product.controller')


module.exports = app => {
    app.get('/api', ProductCtl.index)
    app.post('/api/products', ProductCtl.createProduct)
    app.get('/api/products', ProductCtl.getProducts)
    app.get('/api/products/:id', ProductCtl.oneProduct)
    app.delete('/api/products/:id', ProductCtl.deleteProduct)
    app.put('/api/products/:id', ProductCtl.editProduct)
}