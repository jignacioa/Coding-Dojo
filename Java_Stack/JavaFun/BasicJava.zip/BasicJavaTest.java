import java.util.ArrayList;
public class BasicJavaTest {
    public static void main(String[] args) {
        BasicJava basic = new BasicJava();
        //basic.printNumbers();
        //basic.printOdd();
        //basic.printSum();
        /*int [] X = {1,3,13};
        basic.iterateArray(X);*/
        /*int [] arr = {-2,-9,-11,0,-10,-4};
        basic.findMax(arr);*/
        /*int [] arrAverage = {2,10,3};
        basic.getAverage(arrAverage);*/
        /*ArrayList<Integer> oddArray = new ArrayList<Integer>();
        basic.createOddArray(oddArray);*/
        /*int [] array = {1,5,9,4,11,5,12};
        basic.greaterThanY(array, 10);*/
        /*int [] squaredArray = {2,3,4};
        basic.squareValues(squaredArray);*/
        /*ArrayList<Integer> noNeg = new ArrayList<Integer>();
        noNeg.add(1);
        noNeg.add(-1);
        noNeg.add(2);
        noNeg.add(-2);
        basic.noNegatives(noNeg);*/
        /*int[] numberList = {1,5,10,-2};
        basic.findThreeValues(numberList);*/
        /*ArrayList<Integer> shift = new ArrayList<Integer>();
        shift.add(1);
        shift.add(5);
        shift.add(10);
        shift.add(7);
        shift.add(-2);
        basic.shiftValues(shift);*/

    }
}