import React from 'react'
//import axios from 'axios'
import Form from '../components/productForm'
import ProductList from '../components/productList'


export default () => {
    return (
        <div>
            <Form/>
            <ProductList/> 
        </div>
    )
}