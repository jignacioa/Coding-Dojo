import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.List;

public class PuzzleJavaTest {
    public static void main(String[] args) {
        PuzzleJava puzzleJava = new PuzzleJava();
        /*int[] numbersArray = {3,5,1,2,7,9,8,13,25,32};
        System.out.println(puzzleJava.greaterThan(numbersArray));*/
        /*ArrayList<String> nameList = new ArrayList<String>();
        nameList.add("Nancy");
        nameList.add("Jinichi");
        nameList.add("Fujibayashi");
        nameList.add("Momochi");
        nameList.add("Ishikawa");
        System.out.println(puzzleJava.shuffleNames(nameList));*/
        /*char[] alphaArray = "abcdefghijklmnopqrstuvwxyz".toCharArray();
        puzzleJava.alphabetArray(alphaArray);*/
        //System.out.println(puzzleJava.randomNumbers(100, 55));
        //System.out.println(puzzleJava.randomNumbersSorted(100, 55));
        //puzzleJava.randomString();
        //puzzleJava.randomStringArray();


    }
}
