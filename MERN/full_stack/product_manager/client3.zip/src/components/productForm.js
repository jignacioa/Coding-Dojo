import React, {useState} from 'react'
import axios from 'axios'


export default function Form() {
    const [productName, setName] = useState('')
    const [productPrice, setPrice] = useState(0)
    const [description, setDesc] = useState('')
    
    const handleSubmit = e => {
        e.preventDefault()

        axios.post('http://localhost:8000/api/products', {
            productName, 
            productPrice, 
            description
        })
        .then(res => console.log(res))
        .catch(err => console.log(err))
        setName('')
        setPrice(0)
        setDesc('')

    }

    return (
        <div>
            <h1>Product Manager</h1>
            <form onSubmit ={handleSubmit}>
                <div>
                    <label>Product Name</label>
                    <input 
                    value ={productName}
                    onChange ={e => setName(e.target.value)}/>
                </div>
                <div>
                    <label>Price</label>
                    <input
                    value ={productPrice}
                    onChange ={e => setPrice(e.target.value)} />
                </div>
                <div>
                    <label>Description</label>
                    <input
                    value ={description}
                    onChange ={e => setDesc(e.target.value)}/>
                </div>
                <button type="text">Submit</button>
            </form>
        </div>
    )


}