public class ExceptionsTest {
    public static void main(String[] args) {
        Exceptions test = new Exceptions();
        test.getExceptions();
    }
}