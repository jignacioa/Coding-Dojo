from django.apps import AppConfig


class LoginRegistrationAppConfig(AppConfig):
    name = 'login_registration_app'
