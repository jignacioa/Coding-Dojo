import java.util.HashMap;
public class HashMapFunTest {
public static void main(String[] args) {
    HashMapFun tracks = new HashMapFun();
    tracks.getOneSong();
    tracks.getAllSongs();
 }
 
}